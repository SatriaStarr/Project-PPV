import sqlite3

def create_database():
    # Koneksi ke database SQLite
    conn = sqlite3.connect("transaksi.db")
    cursor = conn.cursor()

    # Membuat tabel tampilan untuk menampilkan data
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tampilan (
        kategori TEXT NOT NULL,
        tanggal TEXT NOT NULL,
        status TEXT NOT NULL,
        nominal REAL NOT NULL,
        akun TEXT NOT NULL,
        id INTEGER PRIMARY KEY AUTOINCREMENT
    )
    """)
    
    # Commit perubahan dan tutup koneksi
    conn.commit()
    conn.close()
    
def insert_data(tanggal, nominal, kategori, status, akun):
    """
    Fungsi untuk menyisipkan data pemasukan atau pengeluaran ke dalam database.
    """
    conn = sqlite3.connect("transaksi.db")
    cursor = conn.cursor()

    cursor.execute("INSERT INTO tampilan (tanggal, nominal, kategori, status, akun) VALUES (?,?,?,?,?)",(tanggal, nominal, kategori, status, akun))
    # Commit perubahan dan tutup koneksi
    conn.commit()
    conn.close()

def get_income_total():
    """
    Fungsi untuk menghitung total nominal dari semua data pemasukan.
    """
    conn = sqlite3.connect("transaksi.db")
    cursor = conn.cursor()

    cursor.execute("SELECT SUM(nominal) FROM tampilan WHERE status = 'Income'")
    total = cursor.fetchone()[0] or 0

    conn.close()
    return total

def get_expense_total():
    """
    Fungsi untuk menghitung total nominal dari semua data pengeluaran.
    """
    conn = sqlite3.connect("transaksi.db")
    cursor = conn.cursor()

    cursor.execute("SELECT SUM(nominal) FROM tampilan WHERE status = 'Expenses'")
    total = cursor.fetchone()[0] or 0

    conn.close()
    return total

def check_tables():
    conn = sqlite3.connect("transaksi.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    print("Tabel dalam database:", tables)
    conn.close()

if __name__ == "__main__":
    create_database()
    check_tables()