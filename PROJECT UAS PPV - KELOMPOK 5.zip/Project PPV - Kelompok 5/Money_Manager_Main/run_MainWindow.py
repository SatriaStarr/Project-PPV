import sys
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QMainWindow, QDialog, QTableWidgetItem, QMessageBox
from mainwindow import Ui_MainWindow
from input import Ui_Dialog
from database import create_database, insert_data
import sqlite3
import matplotlib.pyplot as plt
import calendar

# Kelas dialog untuk input transaksi
class DialogInput(QDialog, Ui_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        # Hubungkan tombol dengan fungsi
        self.setWindowTitle("Input Transaksi")
        self.simpan.clicked.connect(self.save_data)
        self.simpan_2.clicked.connect(self.save_data)

    # Fungsi untuk menyimpan data transaksi   
    def save_data(self):
        try:
            jenis_transaksi = self.tabWidget.currentIndex()
            if jenis_transaksi == 0:  # Income
                nominal = float(self.lineEdit.text())
                akun = self.comboBox_2.currentText()
                status = "Income"
                kategori = self.ldlain_income.text().strip() if self.comboBox.currentText() == 'Etc' else self.comboBox.currentText()
                insert_data(self.tentuTanggal1.dateTime().toString("yyyy-MM-dd HH:mm:ss"), nominal, kategori, status, akun)
            else:  # Expenses
                nominal = float(self.lineEdit_2.text())
                akun = self.comboBox_4.currentText()
                status = "Expenses"
                kategori = self.ldlain_expense.text().strip() if self.comboBox_3.currentText() == 'Etc' else self.comboBox_3.currentText()
                insert_data(self.tentuTanggal1.dateTime().toString("yyyy-MM-dd HH:mm:ss"), nominal, kategori, status, akun)
            
            # Menampilkan pesan setelah berhasil input
            from PySide6.QtWidgets import QMessageBox
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText("Data saved successfully.")
            msg.setWindowTitle("Success")
            msg.exec()
            self.close()
        
        # Menampilkan pesan tidak valid jika memasukkan nominal bukan angka
        except ValueError:
            from PySide6.QtWidgets import QMessageBox
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("Invalid input: Nominal must be a number.")
            msg.setWindowTitle("Error")
            msg.exec()

# Kelas utama untuk aplikasi
class UiUtama(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        create_database()
        self.setupUi(self)
        self.load_data()
        print("Data loaded successfully")
        # Hubungkan tombol dengan fungsi
        self.tambahTransaksi.clicked.connect(self.openInputDialog)
        self.deleteSelectedButton.clicked.connect(self.deleteSelectedRow)
        self.statisticButton.clicked.connect(self.show_statistics)
        self.setWindowTitle("MoneyMaster")  # Set judul jendela utama

    # Fungsi untuk membuka dialog input transaksi
    def openInputDialog(self):
        # Buat instance dialog
        inputDialog = DialogInput()
        inputDialog.exec()
        if inputDialog.close() is True:
            self.retranslateUi(self)
            self.load_data()

    # Fungsi untuk memuat data dari database ke tabel
    def load_data(self):
        conn = sqlite3.connect("transaksi.db")
        cursor = conn.cursor()
        cursor.execute("SELECT kategori, tanggal, nominal, status, akun FROM tampilan WHERE tanggal ORDER BY id DESC")
        data = cursor.fetchall()

        self.tabelDaftarTransaksi.setRowCount(0)
        if data:
            self.tabelDaftarTransaksi.setColumnCount(len(data[0]))
            for row_index, row_data in enumerate(data):
                self.tabelDaftarTransaksi.insertRow(row_index)
                for col_index, cell_data in enumerate(row_data):
                    if col_index == 2:  # Format kolom nominal
                        try:
                            cell_data = f"{int(float(cell_data)):,}".replace(",", ".")
                        except ValueError:
                            pass
                    self.tabelDaftarTransaksi.setItem(row_index, col_index, QTableWidgetItem(str(cell_data)))
        conn.close()

    # Fungsi untuk menghapus baris yang dipilih dari tabel dan database              
    def deleteSelectedRow(self):
            # Hapus data yang dipilih dari database dan tabel tampilan.
            selectedRow = self.tabelDaftarTransaksi.currentRow()
            if selectedRow == -1:
                QMessageBox.warning(None, "Danger", "No data selected.")
                return
            # Ambil ID atau kolom unik dari baris yang dipilih
            try:
                selectedItem = self.tabelDaftarTransaksi.item(selectedRow, 1).text()
            except AttributeError:
                QMessageBox.warning(None, "Error", "Invalid data to delete.")
                return

            confirmation = QMessageBox.question(
                None,
                "Confirm Deletion",
                f"Are you sure you want to delete data?",
                QMessageBox.Yes | QMessageBox.No,
            )

            if confirmation == QMessageBox.Yes:
                try:
                    # Hapus data dari database
                    conn = sqlite3.connect("transaksi.db")
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM tampilan WHERE ROWID = (SELECT ROWID FROM tampilan WHERE tanggal = ? LIMIT 1)", (selectedItem,))
                    # Hapus baris dari tampilan tabel
                    self.tabelDaftarTransaksi.removeRow(selectedRow)
                    conn.commit()
                    conn.close()
                    #QMessageBox.information(None, "Success", f"Data deleted successfully.")
                except Exception as e:
                    QMessageBox.critical(None, "Error", f"Failed to delete data.")
            self.update()
            self.retranslateUi(self)

    # Fungsi menampilkan grafik 
    def show_statistics(self):
        conn = sqlite3.connect("transaksi.db")
        cursor = conn.cursor()

        # Mengambil data income dan expenses per bulan
        cursor.execute("SELECT strftime('%Y-%m', tanggal) AS bulan, SUM(nominal) FROM tampilan WHERE status='Income' GROUP BY bulan")
        income_data = cursor.fetchall()

        cursor.execute("SELECT strftime('%Y-%m', tanggal) AS bulan, SUM(nominal) FROM tampilan WHERE status='Expenses' GROUP BY bulan")
        expenses_data = cursor.fetchall()

        conn.close()

        # Mengolah data
        months = sorted(set([row[0] for row in income_data] + [row[0] for row in expenses_data]))
        income_by_month = {row[0]: row[1] for row in income_data}
        expenses_by_month = {row[0]: row[1] for row in expenses_data}

        income_values = [income_by_month.get(month, 0) for month in months]
        expenses_values = [expenses_by_month.get(month, 0) for month in months]

        # Konversi bulan menjadi nama bulan
        month_labels = [calendar.month_name[int(month.split('-')[1])] + f" {month.split('-')[0]}" for month in months]

        # Membuat grafik batang
        x = range(len(months))
        width = 0.4

        plt.bar(x, income_values, width, label='Income', color='blue')
        plt.bar([i + width for i in x], expenses_values, width, label='Expenses', color='red')

        # Tambahkan total income dan expenses di atas batang
        for i, value in enumerate(income_values):
            plt.text(i, value + (0.05 * max(income_values)), f"{value:,.0f}".replace(",", "."), ha='center', va='bottom', fontsize=9, color='blue')
        for i, value in enumerate(expenses_values):
            plt.text(i + width, value + (0.05 * max(expenses_values)), f"{value:,.0f}".replace(",", "."), ha='center', va='bottom', fontsize=9, color='red')

        plt.xticks([i + width / 2 for i in x], month_labels, rotation=0)
        plt.ylabel('Total Amount')
        plt.xlabel('Month')
        plt.legend()

        # Menampilkan grafik
        plt.tight_layout()
        plt.show()

# Inisialisasi aplikasi
app = QApplication(sys.argv)
window = UiUtama()
window.show()
app.exec()
