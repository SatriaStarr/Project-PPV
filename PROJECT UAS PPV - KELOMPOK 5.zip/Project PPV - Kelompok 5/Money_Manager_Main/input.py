# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'input_transaksi.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDateTimeEdit, QDialog,
    QLabel, QLineEdit, QPushButton, QSizePolicy,
    QTabWidget, QVBoxLayout, QWidget)
import resource_image_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(400, 300)
        self.tabWidget = QTabWidget(Dialog)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(10, 0, 381, 291))
        self.tabWidget.setStyleSheet(u"QTabBar::tab:selected{\n"
"background: white;\n"
"border:1px solid rgb(85, 85, 255);\n"
"}\n"
"QTabBar::tab{\n"
"width: 187;\n"
"height: 20;\n"
"border: 2px solid #e7e7e7;\n"
"background-color: #f5f5f5;\n"
"color: rgb(85, 85, 255);\n"
"font: 700 10pt \"Palatino Linotype\";\n"
"}\n"
"QTabWidget{\n"
"	background-color: rgb(0, 98, 255);\n"
"}")
        self.pemasukkan = QWidget()
        self.pemasukkan.setObjectName(u"pemasukkan")
        self.verticalLayoutWidget = QWidget(self.pemasukkan)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(20, 10, 71, 151))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.tanggal = QLabel(self.verticalLayoutWidget)
        self.tanggal.setObjectName(u"tanggal")
        self.tanggal.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout.addWidget(self.tanggal)

        self.nominal = QLabel(self.verticalLayoutWidget)
        self.nominal.setObjectName(u"nominal")
        self.nominal.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout.addWidget(self.nominal)

        self.kategori = QLabel(self.verticalLayoutWidget)
        self.kategori.setObjectName(u"kategori")
        self.kategori.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout.addWidget(self.kategori)

        self.akun = QLabel(self.verticalLayoutWidget)
        self.akun.setObjectName(u"akun")
        self.akun.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout.addWidget(self.akun)

        self.verticalLayoutWidget_2 = QWidget(self.pemasukkan)
        self.verticalLayoutWidget_2.setObjectName(u"verticalLayoutWidget_2")
        self.verticalLayoutWidget_2.setGeometry(QRect(90, 10, 261, 161))
        self.verticalLayout_2 = QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.tentuTanggal1 = QDateTimeEdit(self.verticalLayoutWidget_2)
        self.tentuTanggal1.setObjectName(u"tentuTanggal1")
        self.tentuTanggal1.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.tentuTanggal1.setDateTime(QDateTime.currentDateTime()) 

        self.verticalLayout_2.addWidget(self.tentuTanggal1)

        self.lineEdit = QLineEdit(self.verticalLayoutWidget_2)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.lineEdit)

        self.comboBox = QComboBox(self.verticalLayoutWidget_2)
        icon = QIcon()
        icon.addFile(u":/icon/image_dan_icon/allowance.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox.addItem(icon, "")
        icon1 = QIcon()
        icon1.addFile(u":/icon/image_dan_icon/money-bags.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox.addItem(icon1, "")
        icon2 = QIcon()
        icon2.addFile(u":/icon/image_dan_icon/rupiah (1).png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox.addItem(icon2, "")
        icon3 = QIcon()
        icon3.addFile(u":/icon/image_dan_icon/gold-medal.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox.addItem(icon3, "")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"")     
        self.verticalLayout_2.addWidget(self.comboBox)
        self.comboBox.currentIndexChanged.connect(self.pemilihanComboBoxIncome)


        self.comboBox_2 = QComboBox(self.verticalLayoutWidget_2)
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.comboBox_2)
        self.tabWidget.addTab(self.pemasukkan, "")

        self.simpan = QPushButton(self.pemasukkan)
        self.simpan.setObjectName(u"simpan")
        self.simpan.setGeometry(QRect(80, 180, 221, 31))
        self.simpan.setStyleSheet(u"color: rgb(85, 85, 255);\n"
"background-color: rgb(255, 255, 255);\n"
"font: 700 10pt \"Palatino Linotype\";\n"
"")
        self.tabWidget.addTab(self.pemasukkan, "")
        # self.simpan.clicked.connect(self.simpan_data)
        self.pengeluaran = QWidget()
        self.pengeluaran.setObjectName(u"pengeluaran")
        self.verticalLayoutWidget_3 = QWidget(self.pengeluaran)
        self.verticalLayoutWidget_3.setObjectName(u"verticalLayoutWidget_3")
        self.verticalLayoutWidget_3.setGeometry(QRect(20, 10, 71, 151))
        self.verticalLayout_3 = QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.tanggal_2 = QLabel(self.verticalLayoutWidget_3)
        self.tanggal_2.setObjectName(u"tanggal_2")
        self.tanggal_2.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_3.addWidget(self.tanggal_2)

        self.nominal_2 = QLabel(self.verticalLayoutWidget_3)
        self.nominal_2.setObjectName(u"nominal_2")
        self.nominal_2.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_3.addWidget(self.nominal_2)

        self.kategori_2 = QLabel(self.verticalLayoutWidget_3)
        self.kategori_2.setObjectName(u"kategori_2")
        self.kategori_2.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_3.addWidget(self.kategori_2)

        self.akun_2 = QLabel(self.verticalLayoutWidget_3)
        self.akun_2.setObjectName(u"akun_2")
        self.akun_2.setStyleSheet(u"font: 700 10pt \"Palatino Linotype\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_3.addWidget(self.akun_2)

        self.verticalLayoutWidget_4 = QWidget(self.pengeluaran)
        self.verticalLayoutWidget_4.setObjectName(u"verticalLayoutWidget_4")
        self.verticalLayoutWidget_4.setGeometry(QRect(90, 10, 261, 161))
        self.verticalLayout_4 = QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.tentuTanggal1_3 = QDateTimeEdit(self.verticalLayoutWidget_4)
        self.tentuTanggal1_3.setObjectName(u"tentuTanggal1_3")
        self.tentuTanggal1_3.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.tentuTanggal1_3.setDateTime(QDateTime.currentDateTime())

        self.verticalLayout_4.addWidget(self.tentuTanggal1_3)

        self.lineEdit_2 = QLineEdit(self.verticalLayoutWidget_4)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.verticalLayout_4.addWidget(self.lineEdit_2)

        self.comboBox_3 = QComboBox(self.verticalLayoutWidget_4)
        icon4 = QIcon()
        icon4.addFile(u":/icon/image_dan_icon/fast-food.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon4, "")
        icon5 = QIcon()
        icon5.addFile(u":/icon/image_dan_icon/cat.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon5, "")
        icon6 = QIcon()
        icon6.addFile(u":/icon/image_dan_icon/public-transport.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon6, "")
        icon7 = QIcon()
        icon7.addFile(u":/icon/image_dan_icon/travel-bag.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon7, "")
        icon8 = QIcon()
        icon8.addFile(u":/icon/image_dan_icon/social-interaction.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon8, "")
        icon9 = QIcon()
        icon9.addFile(u":/icon/image_dan_icon/clothing.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon9, "")
        icon10 = QIcon()
        icon10.addFile(u":/icon/image_dan_icon/chair.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon10, "")
        icon11 = QIcon()
        icon11.addFile(u":/icon/image_dan_icon/makeup.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon11, "")
        icon12 = QIcon()
        icon12.addFile(u":/icon/image_dan_icon/treadmill.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon12, "")
        icon13 = QIcon()
        icon13.addFile(u":/icon/image_dan_icon/stack-of-books.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon13, "")
        icon14 = QIcon()
        icon14.addFile(u":/icon/image_dan_icon/gift.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.comboBox_3.addItem(icon14, "")
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")
        self.comboBox_3.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.comboBox_3.setModelColumn(0)

        self.verticalLayout_4.addWidget(self.comboBox_3)
        self.comboBox_3.currentIndexChanged.connect(self.pemilihanComboBoxExpanse)


        self.comboBox_4 = QComboBox(self.verticalLayoutWidget_4)
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.addItem("")
        self.comboBox_4.setObjectName(u"comboBox_4")
        self.comboBox_4.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.verticalLayout_4.addWidget(self.comboBox_4)

        self.simpan_2 = QPushButton(self.pengeluaran)
        self.simpan_2.setObjectName(u"simpan_2")
        self.simpan_2.setGeometry(QRect(80, 180, 221, 31))
        self.simpan_2.setStyleSheet(u"color: rgb(85, 85, 255);\n"
"background-color: rgb(255, 255, 255);\n"
"font: 700 10pt \"Palatino Linotype\";")
      
        self.tabWidget.addTab(self.pengeluaran, "")

        self.retranslateUi(Dialog)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.tanggal.setText(QCoreApplication.translate("Dialog", u"Date", None))
        self.nominal.setText(QCoreApplication.translate("Dialog", u"Nominal", None))
        self.kategori.setText(QCoreApplication.translate("Dialog", u"Category", None))
        self.akun.setText(QCoreApplication.translate("Dialog", u"Account", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("Dialog", u"Pocket Money", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Dialog", u"Salary", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("Dialog", u"Petty cash", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("Dialog", u"Bonuses", None))
        self.comboBox.setItemText(4, QCoreApplication.translate("Dialog", u"Etc", None))

        self.comboBox_2.setItemText(0, QCoreApplication.translate("Dialog", u"Cash", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("Dialog", u"Credit Card", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("Dialog", u"E-Wallet", None))
        self.simpan.setText(QCoreApplication.translate("Dialog", u"SAVE", None))

        self.tabWidget.setTabText(self.tabWidget.indexOf(self.pemasukkan), QCoreApplication.translate("Dialog", u"Income", None))
        self.tanggal_2.setText(QCoreApplication.translate("Dialog", u"Date", None))
        self.nominal_2.setText(QCoreApplication.translate("Dialog", u"Nominal", None))
        self.kategori_2.setText(QCoreApplication.translate("Dialog", u"Category", None))
        self.akun_2.setText(QCoreApplication.translate("Dialog", u"Account", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("Dialog", u"Food", None))
        self.comboBox_3.setItemText(1, QCoreApplication.translate("Dialog", u"Pet", None))
        self.comboBox_3.setItemText(2, QCoreApplication.translate("Dialog", u"Transportation", None))
        self.comboBox_3.setItemText(3, QCoreApplication.translate("Dialog", u"Holiday", None))
        self.comboBox_3.setItemText(4, QCoreApplication.translate("Dialog", u"Social Life", None))
        self.comboBox_3.setItemText(5, QCoreApplication.translate("Dialog", u"Clothes", None))
        self.comboBox_3.setItemText(6, QCoreApplication.translate("Dialog", u"Household", None))
        self.comboBox_3.setItemText(7, QCoreApplication.translate("Dialog", u"Beauty", None))
        self.comboBox_3.setItemText(8, QCoreApplication.translate("Dialog", u"Health", None))
        self.comboBox_3.setItemText(9, QCoreApplication.translate("Dialog", u"Education", None))
        self.comboBox_3.setItemText(10, QCoreApplication.translate("Dialog", u"Present", None))
        self.comboBox_3.setItemText(11, QCoreApplication.translate("Dialog", u"Etc", None))

        self.comboBox_4.setItemText(0, QCoreApplication.translate("Dialog", u"Cash", None))
        self.comboBox_4.setItemText(1, QCoreApplication.translate("Dialog", u"Credit Card", None))
        self.comboBox_4.setItemText(2, QCoreApplication.translate("Dialog", u"E-Wallet", None))

        self.simpan_2.setText(QCoreApplication.translate("Dialog", u"SAVE", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.pengeluaran), QCoreApplication.translate("Dialog", u"Expenses", None))
    # retranslateUi
        # ini widget tambahan jika lain lainya telah diklik
        # self.ldlain = QLineEdit()
        # QLineEdit untuk masing-masing tab
        self.ldlain_income = QLineEdit()
        self.ldlain_expense = QLineEdit()

    def pemilihanComboBoxIncome(self,index):
        if index == 4:  # Index 4 adalah "Etc"
                # Tampilkan QLineEdit untuk "Etc"
                self.ldlain_income.show()
                self.comboBox.hide()
                # self.lblain.show()
                # Masukkan QLineEdit ke dalam layout income
                if not self.ldlain_income.parent():  # Tambahkan hanya jika belum ada
                        self.verticalLayout_2.insertWidget(3, self.ldlain_income)
        else:
                self.ldlain_income.hide()
                self.comboBox.show()
                
                # ini menambh Qline edit untuk pengimpulan lain lainya dibawah combobox kategori lain lain
                # self.verticalLayout_2.insertWidget(3, self.lblain)
                # self.verticalLayout_2.insertWidget(3, self.ldlain)

                # Pindahkan comboBox_2 ke bawah ldlain
                # self.verticalLayout_2.addWidget(self.comboBox)

        # else:
        #         # Sembunyikan "Lain-Lain" widget jika pilihan lain dipilih
        #         # self.lblain.hide()
        #         self.ldlain.hide()
        #         self.comboBox.show()

        #         # Pastikan comboBox tetap di layout
        #         self.verticalLayout_2.addWidget(self.comboBox)

    def pemilihanComboBoxExpanse(self,index):
        if index == 11:  # Index 4 adalah "Lain-Lain"                
                 # Tampilkan QLineEdit dn Qlabel untuk "Lain-Lain"
                self.ldlain_expense.show()
                self.comboBox_3.hide()
                # self.lblain.show()
                # Masukkan QLineEdit ke dalam layout expense
                if not self.ldlain_expense.parent():  # Tambahkan hanya jika belum ada
                        self.verticalLayout_4.insertWidget(3, self.ldlain_expense)
        else:
                self.ldlain_expense.hide()
                self.comboBox_3.show()
                
                # ini menambh Qline edit untuk pengimpulan lain lainya dibawah combobox kategori lain lain
                # self.verticalLayout_2.insertWidget(3, self.lblain)
                # self.verticalLayout_4.insertWidget(3, self.ldlain)

                
                # Pindahkan comboBox_3 ke bawah ldlain
                # self.verticalLayout_4.addWidget(self.comboBox_3)

        # else:
        #         # Sembunyikan "Lain-Lain" widget jika pilihan lain dipilih
        #         # self.lblain.hide()
        #         self.ldlain.hide()
        #         self.comboBox_3.show()
        #         # Pastikan comboBox_3 tetap di layout
        #         self.verticalLayout_4.addWidget(self.comboBox_3)
