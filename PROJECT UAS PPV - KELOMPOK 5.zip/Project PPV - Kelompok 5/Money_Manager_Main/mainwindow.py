# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow_transaksi.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHeaderView, QLabel,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QStatusBar, QTabWidget, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget, QMessageBox)
from input import Ui_Dialog
import resource_image_rc
import locale
locale.setlocale(locale.LC_ALL, 'id_ID.UTF-8')

import sqlite3

from database import get_expense_total, get_income_total

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):

        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(900, 650)
        MainWindow.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 60, 771, 450))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tabWidget.sizePolicy().hasHeightForWidth())
        self.tabWidget.setSizePolicy(sizePolicy)
        self.tabWidget.setMinimumSize(QSize(900, 650))
        self.tabWidget.setBaseSize(QSize(900, 750))
        self.tabWidget.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.tabWidget.setAutoFillBackground(False)
        self.tabWidget.setStyleSheet(u"QTabBar::tab:selected{\n"
"background: white;\n"
"border:1px solid rgb(0, 0, 255);\n"
"}\n"
"QTabBar::tab{\n"
"width: 446;\n"
"height: 20;\n"
"border: 2px solid #e7e7e7;\n"
"background-color: #f5f5f5;\n"
"color: rgb(85, 85, 255);\n"
"font: 700 10pt \"Palatino Linotype\";\n"
"}\n"
"QTabWidget{\n"
"background-color: rgb(85, 170, 255);\n"
"}\n"
"")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Rounded)
        self.tabWidget.setIconSize(QSize(20, 20))
        self.tabWidget.setMovable(True)
        self.homepage = QWidget()
        self.homepage.setObjectName(u"homepage")
        self.judul_MoneyManager = QLabel(self.homepage)
        self.judul_MoneyManager.setObjectName(u"judul_MoneyManager")
        self.judul_MoneyManager.setGeometry(QRect(30, 78, 280, 60))
        self.judul_MoneyManager.setStyleSheet(u"font: 26pt \"Impact\";\n"
"color: rgb(85, 85, 255);")
        self.label_13 = QLabel(self.homepage)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(30, 120, 270, 30))
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label_13.sizePolicy().hasHeightForWidth())
        self.label_13.setSizePolicy(sizePolicy1)
        self.label_13.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)
        self.label_13.setStyleSheet(u"font: 600 12pt \"Segoe UI Semibold\";\n"
"color: rgb(0, 0, 0);")
        self.label_13.setLineWidth(0)
        self.label_13.setTextFormat(Qt.TextFormat.AutoText)
        self.label_13.setScaledContents(True)
        self.label_13.setWordWrap(False)
        self.label_13.setMargin(0)
        self.label_13.setIndent(0)
        self.label_13.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse)
        self.label_14 = QLabel(self.homepage)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(30, 96, 161, 400))
        self.label_14.setStyleSheet(u"image: url(:/image/image_dan_icon/wallet.png);")
        
        self.verticalLayoutWidget_4 = QWidget(self.homepage)
        self.verticalLayoutWidget_4.setObjectName(u"verticalLayoutWidget_4")
        self.verticalLayoutWidget_4.setGeometry(QRect(420, 100, 450, 250))
        self.verticalLayout_4 = QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_4.setSpacing(6)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 9)

        self.Income = QLabel(self.verticalLayoutWidget_4)
        self.Income.setObjectName(u"Income")
        self.Income.setStyleSheet(u"font: 600 12pt \"Segoe UI Semibold\";\n"
"color: rgb(0, 0, 0);\n"
"border: 2px solid  rgb(85, 85, 255);\n"
"")

        self.verticalLayout_4.addWidget(self.Income)

        self.Expenses = QLabel(self.verticalLayoutWidget_4)
        self.Expenses.setObjectName(u"Expenses")
        self.Expenses.setStyleSheet(u"font: 600 12pt \"Segoe UI Semibold\";\n"
"color: rgb(0, 0, 0);\n"
"border: 2px solid  rgb(85, 85, 255);\n"
"")

        self.verticalLayout_4.addWidget(self.Expenses)

        self.Total = QLabel(self.verticalLayoutWidget_4)
        self.Total.setObjectName(u"Total")
        self.Total.setStyleSheet(u"font: 600 12pt \"Segoe UI Semibold\";\n"
"color: rgb(0, 0, 0);\n"
"border: 2px solid  rgb(85, 85, 255);\n"
"")

        self.verticalLayout_4.addWidget(self.Total)

        self.label_21 = QLabel(self.homepage)
        self.label_21.setObjectName(u"new_label_name")
        self.label_21.setGeometry(QRect(450, 40, 380, 40))
        font = QFont()
        font.setFamilies([u"Segoe UI"])
        font.setPointSize(5)
        font.setWeight(QFont.DemiBold)
        font.setItalic(False)
        self.label_21.setFont(font)
        self.label_21.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        self.label_21.setStyleSheet(u"color: rgb(2, 2, 2);\n"
"font: 600 15pt \"Segoe UI\";\n"
"")

        self.label_21.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_22 = QLabel(self.homepage)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(30, 144, 270, 30))
        sizePolicy1.setHeightForWidth(self.label_22.sizePolicy().hasHeightForWidth())
        self.label_22.setSizePolicy(sizePolicy1)
        self.label_22.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)
        self.label_22.setStyleSheet(u"font: 600 12pt \"Segoe UI Semibold\";\n"
"color: rgb(0, 0, 0);")
        self.label_22.setLineWidth(0)
        self.label_22.setTextFormat(Qt.TextFormat.AutoText)
        self.label_22.setScaledContents(True)
        self.label_22.setWordWrap(False)
        self.label_22.setMargin(0)
        self.label_22.setIndent(0)
        self.label_22.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse)
        self.frame = QFrame(self.homepage)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(-5, 20, 910, 500))
        self.frame.setStyleSheet(u"color: rgb(85, 85, 255);")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayoutWidget_5 = QWidget(self.frame)
        self.verticalLayoutWidget_5.setObjectName(u"verticalLayoutWidget_5")
        self.verticalLayoutWidget_5.setGeometry(QRect(360, 70, 51, 250))
        self.verticalLayout_5 = QVBoxLayout(self.verticalLayoutWidget_5)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.iconIncome = QLabel(self.verticalLayoutWidget_5)
        self.iconIncome.setObjectName(u"iconIncome")
        self.iconIncome.setStyleSheet(u"image: url(:/image/image_dan_icon/save-money.png);")

        self.verticalLayout_5.addWidget(self.iconIncome)

        self.iconExpenses = QLabel(self.verticalLayoutWidget_5)
        self.iconExpenses.setObjectName(u"iconExpenses")
        self.iconExpenses.setSizeIncrement(QSize(0, 0))
        self.iconExpenses.setBaseSize(QSize(1, 0))
        self.iconExpenses.setStyleSheet(u"image: url(:/image/image_dan_icon/expenses (1).png);\n"
"color: rgb(255, 255, 255);\n"
"")
        self.iconExpenses.setFrameShape(QFrame.Shape.NoFrame)
        self.iconExpenses.setFrameShadow(QFrame.Shadow.Plain)

        self.verticalLayout_5.addWidget(self.iconExpenses)

        self.iconGrafikTotal = QLabel(self.verticalLayoutWidget_5)
        self.iconGrafikTotal.setObjectName(u"iconGrafikTotal")
        self.iconGrafikTotal.setStyleSheet(u"image: url(:/image/image_dan_icon/bar-chart.png);")

        self.verticalLayout_5.addWidget(self.iconGrafikTotal)

        self.tambahTransaksi = QPushButton(self.frame)
        self.tambahTransaksi.setObjectName(u"tambahTransaksi")
        self.tambahTransaksi.setGeometry(QRect(780, 350, 61, 61))
        self.tambahTransaksi.setStyleSheet(u"QPushButton {\n"
"    width: 96px;          \n"
"    height: 96px;     \n"
"    border-radius: 30;  \n"
"	background-color: qlineargradient(spread:reflect, x1:0.274725, y1:0.261, x2:1, y2:1, stop:0.346154 rgba(17, 0, 248, 255), stop:1 rgba(255, 255, 255, 255));\n"
"	color: rgb(255, 255, 255);\n"
"	font: 700 20pt \"Segoe UI\";\n"
"}")
        self.tabWidget.addTab(self.homepage, "")
        self.frame.raise_()
        self.judul_MoneyManager.raise_()
        self.label_13.raise_()
        self.label_14.raise_()
        self.verticalLayoutWidget_4.raise_()
        self.label_21.raise_()
        self.label_22.raise_()
        self.DaftarTransaksi = QWidget()
        self.DaftarTransaksi.setObjectName(u"DaftarTransaksi")
        self.statisticButton = QPushButton(self.DaftarTransaksi)
        self.statisticButton.setObjectName("statisticButton")
        self.statisticButton.setText("View Statistic")
        self.statisticButton.setGeometry(QRect(720, 490, 160, 40))
        self.statisticButton.setStyleSheet("font: 600 10pt \"Segoe UI Semibold\";\n"
                                                "color: white;\n"
                                                "background-color: blue;\n"
                                                "border-radius: 10px;")
        self.deleteSelectedButton = QPushButton(self.DaftarTransaksi)
        self.deleteSelectedButton.setObjectName("deleteSelectedButton")
        self.deleteSelectedButton.setText("Delete Selected Data")
        self.deleteSelectedButton.setGeometry(QRect(20, 490, 160, 40))
        self.deleteSelectedButton.setStyleSheet("font: 600 10pt \"Segoe UI Semibold\";\n"
                                                "color: white;\n"
                                                "background-color: orange;\n"
                                                "border-radius: 10px;")
       
        self.tabelDaftarTransaksi = QTableWidget(self.DaftarTransaksi)
        if (self.tabelDaftarTransaksi.columnCount() < 5):
            self.tabelDaftarTransaksi.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.tabelDaftarTransaksi.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        if (self.tabelDaftarTransaksi.rowCount() < 13):
            self.tabelDaftarTransaksi.setRowCount(13)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(0, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(1, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(2, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(3, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(4, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(5, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(6, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(7, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(8, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(9, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(10, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(11, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        self.tabelDaftarTransaksi.setVerticalHeaderItem(12, __qtablewidgetitem16)
        self.tabelDaftarTransaksi.setObjectName(u"tabelDaftarTransaksi")
        self.tabelDaftarTransaksi.setGeometry(QRect(6, 20, 1200, 450))
        self.tabelDaftarTransaksi.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.tabelDaftarTransaksi.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.tabelDaftarTransaksi.setAutoFillBackground(True)
        self.tabelDaftarTransaksi.setStyleSheet("QTableWidget{\n"
"colomns-width: 100;\n"
"height: 20;\n"
"border: 2px solid #e7e7e7;\n"
"color: rgb(85, 85, 255);\n"
"background: #f5f5f5;\n"
"background-color: #f5f5f5;\n"
"}")
        self.tabelDaftarTransaksi.horizontalHeader().setMinimumSectionSize(35)
        self.tabelDaftarTransaksi.horizontalHeader().setDefaultSectionSize(174)
        self.tabWidget.addTab(self.DaftarTransaksi, "")
        self.Title = QLabel(self.centralwidget)
        self.Title.setObjectName("Title")
        self.Title.setGeometry(QRect(300, 10, 301, 31))
        self.Title.setStyleSheet("color: rgb(85, 85, 255);\n"
"font: 700 12pt \"Century Schoolbook\";")
        self.Title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName("menubar")
        self.menubar.setGeometry(QRect(0, 0, 806, 33))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)

    # setupUi
    def retranslateUi(self, MainWindow):

        total_income = get_income_total()
        total_expense = get_expense_total()
        net_total = total_income - total_expense

        # Format angka dengan separator
        formatted_income = locale.format_string("%d", total_income, grouping=True)
        formatted_expense = locale.format_string("%d", total_expense, grouping=True)
        formatted_total = locale.format_string("%d", net_total, grouping=True)
        self.judul_MoneyManager.setText(QCoreApplication.translate("MainWindow", "<html><head/><body><p><span style=\" font-size:11pt;\">MONEY MANAGER</span></p></body></html>", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", "<html><head/><body><p>Helps manage personal finances</p></body></html>", None))
        self.label_14.setText("")
        self.Income.setText(QCoreApplication.translate("MainWindow", f'Income              :  Rp{formatted_income}', None))
        self.Expenses.setText(QCoreApplication.translate("MainWindow", f'Expenses           :   Rp{formatted_expense}', None))
        self.Total.setText(QCoreApplication.translate("MainWindow", f'Total                  :   Rp{formatted_total}', None))
        self.label_21.setText(QCoreApplication.translate("MainWindow", "<html><head/><body><p>Come on, manage your personal finances!</p></body></html>", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", "<html><head/><body><p>easily, precisely and quickly</p></body></html>", None))
        self.iconIncome.setText("")
        self.iconExpenses.setText("")
        self.iconGrafikTotal.setText("")
        self.tambahTransaksi.setText(QCoreApplication.translate("MainWindow", "+", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.homepage), QCoreApplication.translate("MainWindow", u"Homepage", None))
        ___qtablewidgetitem = self.tabelDaftarTransaksi.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", "Category", None));
        ___qtablewidgetitem1 = self.tabelDaftarTransaksi.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", "Date", None));
        ___qtablewidgetitem2 = self.tabelDaftarTransaksi.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", "Nominal", None));
        ___qtablewidgetitem3 = self.tabelDaftarTransaksi.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", "Status", None));
        ___qtablewidgetitem4 = self.tabelDaftarTransaksi.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", "Account", None));
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.DaftarTransaksi), QCoreApplication.translate("MainWindow", u"Transaction List", None))
        self.Title.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:22pt; font-weight:700;\">MONEY MANAGER</span></p><p><br/></p></body></html>", None))
    # retranslateUi
