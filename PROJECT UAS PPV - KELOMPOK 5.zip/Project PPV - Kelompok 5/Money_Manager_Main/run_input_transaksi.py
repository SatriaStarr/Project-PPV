import random
import sys
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtGui import QFont
from input import Ui_Dialog

class MainWindow(QMainWindow, Ui_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

# Fungsi untuk mengatur properti jendela utama
def mainwindow_setup(w):
    w.setWindowTitle("Input")
  
app = QApplication(sys.argv)
window = MainWindow()
mainwindow_setup(window)
window.show()
app.exec()